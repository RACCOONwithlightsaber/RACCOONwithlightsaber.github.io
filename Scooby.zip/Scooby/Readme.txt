

- Free version < Press Free then Press get key and enter it


- Paid Version < Purchase a Key from the Store & Make sure to Save it 


Updater.bat will Auto Update the Loader so everytime, Scooby gets a Update just run the Updater then it will auto downloaded the newest version

Discord: https://discord.gg/yUp78V8tgM
Telegram: https://t.me/ScoobyOnTop